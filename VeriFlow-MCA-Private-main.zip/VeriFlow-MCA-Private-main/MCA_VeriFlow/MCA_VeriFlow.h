﻿#include <iostream>
#include <string>

class MCA_VeriFlow {
	public:
		MCA_VeriFlow();
		void run();
		void stop();
	private:
	
};